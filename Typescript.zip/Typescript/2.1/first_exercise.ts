// Exercise 1: Refactoring JavaScript to TypeScript


// TODO:

// Convert the following JavaScript code into TypeScript:

// function multiply(a, b) {
//     return a * b;
// }

function multiply(a:number, b:number):number{
    return a*b;
}
console.log(multiply(3,4));