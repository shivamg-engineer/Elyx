// Exercise 2: Debugging Type Errors

// Identify the type error in the following TypeScript code and fix it:

let age: number;
// age = "25"; // Fix this issue
age=25;