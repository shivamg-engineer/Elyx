var username = "shivam";
console.log(username);
