let username:string ="shivam";
console.log(username);

document.body.innerHTML = "<h1>Hello, TypeScript!</h1>";