// import { greet } from "./second_exercise";

// const message = greet("Shivam");
// console.log(message);

import greet = require("./second_exercise");

console.log(greet("Shivam"));

