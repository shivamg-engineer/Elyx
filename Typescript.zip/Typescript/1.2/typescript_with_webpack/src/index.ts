const greet = (name: string): string => {
  return `Hello, ${name}!`;
};

console.log(greet('Webpack + TypeScript'));
