import   {add, subtract} from "./mathUtils.ts";

console.log(add(4,6));
console.log(subtract(8,3));