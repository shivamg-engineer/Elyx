import { capitalize,reverseString,isEven } from "./utils.ts";


console.log(capitalize("hello"));      // Output: Hello
console.log(reverseString("hello"));   // Output: olleh
console.log(isEven(10));                // Output: true
console.log(isEven(7));                 // Output: false