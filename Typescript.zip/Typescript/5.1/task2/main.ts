import { add, subtract } from "./mathUtils.ts";
console.log(add(5, 3));
console.log(subtract(10, 6));
