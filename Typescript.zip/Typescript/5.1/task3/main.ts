import logMessage from "./logger.ts";
logMessage("This is a test message");
