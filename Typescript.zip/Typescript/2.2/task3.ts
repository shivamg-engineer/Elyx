type UserTuple=[string, number, boolean];

const user1: UserTuple = ["Alice", 25, true];
console.log(user1[0]); // Alice