// Exercise 1: Define an Employee Type

// TODO: Create a type for an employee that includes id, name, position, and an optional department.

type Employee={
    id: number,
    name:string,
    position:string,
    department?: string
}