// Use Type Alias: Create a UserRole type alias with values 'admin' | 'user' | 'guest'.

type UserRole = 'admin' | 'user' | 'guest';
