// Create an Interface: Define an interface for a Product with properties id, name, price, and an optional discount.
interface Product2{
    id : number,
    name: string,
    price: number,
    discount?:number
}