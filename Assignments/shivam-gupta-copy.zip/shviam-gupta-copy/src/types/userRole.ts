export type UserRole=  "ADMIN"
  | "INSTITUTE"
  | "JD"
  | "DIRECTOR"
  | "SECRETARY";