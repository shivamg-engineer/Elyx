export const demoUsers = [
  { 
    username: "admin", 
    password: "admin", 
    role: "ADMIN",
    name: "Admin User",
    email: "admin@dhe.gov.in"
  },
  { 
    username: "institute", 
    password: "institute", 
    role: "INSTITUTE",
    name: "Institute User",
    email: "institute@dhe.gov.in"
  },
  { 
    username: "jd", 
    password: "jd", 
    role: "JD",
    name: "Joint Director",
    email: "jd@dhe.gov.in"
  },
  { 
    username: "director", 
    password: "director", 
    role: "DIRECTOR",
    name: "Director User",
    email: "director@dhe.gov.in"
  },
  { 
    username: "secretary", 
    password: "secretary", 
    role: "SECRETARY",
    name: "Secretary User",
    email: "secretary@dhe.gov.in"
  }
];
