import DashboardLayout from "../../layout/DashboardLayout";
import { useEffect, useRef, useState } from "react";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import styles from "./InstituteRegister.module.css";

type FormDataType = {
  instituteName: string;
  instituteType: string;
  apexBody: string;
  addressLine1: string;
  addressLine2: string;
  city: string;
  district: string;
  state: string;
  pincode: string;
  principalName: string;
  principalMobile: string;
  principalEmail: string;
  principalAltPhone: string;
  registrarName: string;
  registrarEmail: string;
  registrarMobile: string;
  registrarAltPhone: string;
};

const LOCAL_DRAFT_KEY = "instituteDraft_v1";
const LOCAL_FILE_KEY = "instituteDraft_fileName_v1";

export function InstituteRegister() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const [activeTab] = useState<"A" | "B" | "C">("A"); // tabs visible; B/C disabled
  const [progressPercent, setProgressPercent] = useState(33);

  const [formData, setFormData] = useState<FormDataType>({
    instituteName: "",
    instituteType: "",
    apexBody: "",
    addressLine1: "",
    addressLine2: "",
    city: "",
    district: "",
    state: "Maharashtra",
    pincode: "",
    principalName: "",
    principalMobile: "",
    principalEmail: "",
    principalAltPhone: "",
    registrarName: "",
    registrarEmail: "",
    registrarMobile: "",
    registrarAltPhone: "",
  });

  const [file, setFile] = useState<File | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  // showErrors = false until user clicks Next Step
  const [showErrors, setShowErrors] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    // Load saved draft + file name
    const raw = localStorage.getItem(LOCAL_DRAFT_KEY);
    const savedFileName = localStorage.getItem(LOCAL_FILE_KEY);

    if (raw) {
      try {
        const parsed = JSON.parse(raw) as FormDataType;
        setFormData(parsed);
        toast.info("Draft loaded");
      } catch {
        // ignore
      }
    }
    if (savedFileName) setFileName(savedFileName);

    setProgressPercent(33);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const updateField = (key: keyof FormDataType, value: string) => {
    setFormData((prev) => ({ ...prev, [key]: value }));

    // If we've started showing errors, validate this field live and clear error if valid
    if (showErrors) {
      const err = validateSingleField(key, value);
      setErrors((prev) => {
        const copy = { ...prev };
        if (!err) delete copy[key as string];
        else copy[key as string] = err;
        return copy;
      });
    }
  };

  // Single-field validation (returns error message or empty string)
  const validateSingleField = (key: keyof FormDataType, value: string): string => {
    const trimmed = value.trim();
    const nameRegex = /^[A-Za-z\s]+$/;
    const mobileRegex = /^\d{10}$/;
    const pincodeRegex = /^\d{6}$/;
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[A-Za-z]{2,}$/;

    switch (key) {
      case "instituteName":
        if (!trimmed) return "Institute Name is required";
        if (!nameRegex.test(trimmed)) return "Institute Name should contain letters and spaces only";
        return "";
      case "instituteType":
        if (!trimmed) return "Institute Type is required";
        return "";
      case "addressLine1":
        if (!trimmed) return "Address Line 1 is required";
        return "";
      case "city":
        if (!trimmed) return "City is required";
        return "";
      case "district":
        if (!trimmed) return "District is required";
        return "";
      case "pincode":
        if (!pincodeRegex.test(trimmed)) return "Pincode must be exactly 6 digits";
        return "";
      case "principalName":
        if (!trimmed) return "Principal Name is required";
        if (!nameRegex.test(trimmed)) return "Principal Name should contain letters and spaces only";
        return "";
      case "principalMobile":
        if (!mobileRegex.test(trimmed)) return "Principal Mobile must be exactly 10 digits";
        return "";
      case "principalEmail":
        if (!emailRegex.test(trimmed)) return "Principal Email is invalid";
        return "";
      case "registrarName":
        if (!trimmed) return "Registrar Name is required";
        if (!nameRegex.test(trimmed)) return "Registrar Name should contain letters and spaces only";
        return "";
      case "registrarMobile":
        if (!mobileRegex.test(trimmed)) return "Registrar Mobile must be exactly 10 digits";
        return "";
      case "registrarEmail":
        if (!emailRegex.test(trimmed)) return "Registrar Email is invalid";
        return "";
      default:
        return "";
    }
  };

  const validateAll = (): Record<string, string> => {
    const res: Record<string, string> = {};
    (Object.keys(formData) as (keyof FormDataType)[]).forEach((k) => {
      const err = validateSingleField(k, String(formData[k]));
      if (err) res[k as string] = err;
    });

    // file required
    if (!file && !fileName) {
      res["file"] = "Apex Body Permission Document is required";
    }

    return res;
  };

  // File selection + validation (type + size)
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploaded = e.target.files?.[0];
    if (!uploaded) return;

    const allowed = ["pdf", "jpg", "jpeg", "png"];
    const maxSize = 5 * 1024 * 1024; // 5MB

    const ext = uploaded.name.split(".").pop()?.toLowerCase() ?? "";
    if (!allowed.includes(ext)) {
      toast.error("File type not allowed. Use PDF / JPG / PNG.");
      return;
    }
    if (uploaded.size > maxSize) {
      toast.error("File exceeds 5MB limit.");
      return;
    }

    setFile(uploaded);
    setFileName(uploaded.name);
    localStorage.setItem(LOCAL_FILE_KEY, uploaded.name);
    toast.success("File selected");
    // clear file error if present and showErrors true
    if (showErrors) setErrors((prev) => { const cp = { ...prev }; delete cp["file"]; return cp; });
  };

  const saveDraft = () => {
    localStorage.setItem(LOCAL_DRAFT_KEY, JSON.stringify(formData));
    if (fileName) localStorage.setItem(LOCAL_FILE_KEY, fileName);
    toast.success("Draft saved");
  };

  const handleNextStep = () => {
    setShowErrors(true);

    const validation = validateAll();
    setErrors(validation);

    if (Object.keys(validation).length > 0) {
      // show first error as toast for quick feedback
      const first = validation[Object.keys(validation)[0]];
      toast.error(first);
      // scroll to first invalid field (if exists)
      const firstFieldKey = Object.keys(validation)[0];
      const el = document.querySelector(`[data-field="${firstFieldKey}"]`);
      if (el) (el as HTMLElement).scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }

    // All good — save draft and navigate
    saveDraft();
    toast.success("Part A validated — proceeding to profile");
    navigate("/institute-registration/profile");
  };

  // Helper to get input class with error border when showErrors && error exists
  const inputClass = (fieldKey: string) =>
    `${styles.inputElement} ${showErrors && errors[fieldKey] ? styles.errorInput : ""}`;

  return (
    <DashboardLayout>
      <div className={styles.container}>
        <h1 className={styles.pageTitle}>Institute Registration</h1>
        <p className={styles.subtitle}>
          Complete Part A to register your institution (Parts B & C are skipped).
        </p>

        {/* Step header */}
        <div className={styles.stepHeader}>
          <div>
            <p className={styles.stepLabel}>Step 1 of 3</p>
            <div className={styles.progressBar}>
              <div className={styles.progressFill} style={{ width: `${progressPercent}%` }} />
            </div>
          </div>
          <span className={styles.progressText}>{progressPercent}% Complete</span>
        </div>

        {/* Tabs */}
        <div className={styles.stepTabs}>
          <button className={`${styles.tab} ${styles.activeTab}`} onClick={() => {/* noop: A active */}}>
            Part A: Basic Information
          </button>
          <button
            className={styles.tab}
            onClick={() => toast.info("Part B skipped in this flow")}
          >
            Part B: Recognition & Status
          </button>
          <button
            className={styles.tab}
            onClick={() => toast.info("Part C skipped in this flow")}
          >
            Part C: Courses & Intake
          </button>
        </div>

        {/* Part A content */}
        <h2 className={styles.sectionHeading}>Part A: Basic Information</h2>
        <p className={styles.sectionDesc}>Enter institute details and contact information</p>

        {/* Basic info */}
        <section className={styles.card}>
          <h3 className={styles.cardTitle}>Basic Information</h3>
          <div className={styles.grid1}>
            <div className={styles.inputGroup}>
              <label>Institute Name *</label>
              <input
                data-field="instituteName"
                className={inputClass("instituteName")}
                value={formData.instituteName}
                onChange={(e) => updateField("instituteName", e.target.value)}
                placeholder="Enter Institute name"
              />
              {showErrors && errors.instituteName && <p className={styles.errorText}>{errors.instituteName}</p>}
            </div>

            <div className={styles.inputGroup}>
              <label>Institute Type *</label>
              <select
                data-field="instituteType"
                className={inputClass("instituteType")}
                value={formData.instituteType}
                onChange={(e) => updateField("instituteType", e.target.value)}
              >
                <option value="">Select Institute type</option>
                <option>Government</option>
                <option>Private</option>
                <option>Aided</option>
              </select>
              {showErrors && errors.instituteType && <p className={styles.errorText}>{errors.instituteType}</p>}
            </div>

            <div className={styles.inputGroup}>
              <label>Apex Body</label>
              <input
                data-field="apexBody"
                className={styles.inputElement}
                value={formData.apexBody}
                onChange={(e) => updateField("apexBody", e.target.value)}
                placeholder="e.g., University Grants Commission"
              />
            </div>

            <div className={styles.inputGroupFull}>
              <label>Apex Body Permission Document *</label>

              <div
                className={styles.uploadBox}
                onClick={() => fileInputRef.current?.click()}
                role="button"
                tabIndex={0}
              >
                <div className={styles.uploadInner}>⬆️ <p>Drag & drop files here</p><small>or <span className={styles.browse}>browse files</span></small></div>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                className={styles.hiddenInput}
                onChange={handleFileSelect}
                data-field="file"
              />

              {showErrors && errors.file && <p className={styles.errorText}>{errors.file}</p>}
              {fileName && <p className={styles.fileName}>Selected File: {fileName}</p>}
            </div>
          </div>
        </section>

        {/* Address */}
        <section className={styles.card}>
          <h3 className={styles.cardTitle}>Address Information</h3>

          <div className={styles.grid1}>
            <div className={styles.inputGroup}>
              <label>Address Line 1 *</label>
              <input
                data-field="addressLine1"
                className={inputClass("addressLine1")}
                value={formData.addressLine1}
                onChange={(e) => updateField("addressLine1", e.target.value)}
                placeholder="Building name, street"
              />
              {showErrors && errors.addressLine1 && <p className={styles.errorText}>{errors.addressLine1}</p>}
            </div>

            <div className={styles.inputGroup}>
              <label>Address Line 2</label>
              <input
                data-field="addressLine2"
                className={styles.inputElement}
                value={formData.addressLine2}
                onChange={(e) => updateField("addressLine2", e.target.value)}
                placeholder="Area, locality (optional)"
              />
            </div>

            <div className={styles.grid2}>
              <div className={styles.inputGroup}>
                <label>City *</label>
                <input
                  data-field="city"
                  className={inputClass("city")}
                  value={formData.city}
                  onChange={(e) => updateField("city", e.target.value)}
                  placeholder="Enter city"
                />
                {showErrors && errors.city && <p className={styles.errorText}>{errors.city}</p>}
              </div>

              <div className={styles.inputGroup}>
                <label>District *</label>
                <input
                  data-field="district"
                  className={inputClass("district")}
                  value={formData.district}
                  onChange={(e) => updateField("district", e.target.value)}
                  placeholder="Enter district"
                />
                {showErrors && errors.district && <p className={styles.errorText}>{errors.district}</p>}
              </div>

              <div className={styles.inputGroup}>
                <label>State *</label>
                <select
                  data-field="state"
                  className={inputClass("state")}
                  value={formData.state}
                  onChange={(e) => updateField("state", e.target.value)}
                >
                  <option>Maharashtra</option>
                  <option>Delhi</option>
                  <option>Karnataka</option>
                </select>
              </div>

              <div className={styles.inputGroup}>
                <label>Pincode *</label>
                <input
                  data-field="pincode"
                  className={inputClass("pincode")}
                  value={formData.pincode}
                  onChange={(e) => updateField("pincode", e.target.value)}
                  placeholder="6-digit pincode"
                />
                {showErrors && errors.pincode && <p className={styles.errorText}>{errors.pincode}</p>}
              </div>
            </div>
          </div>
        </section>

        {/* Principal */}
        <section className={styles.card}>
          <h3 className={styles.cardTitle}>Principal Contact Information</h3>
          <div className={styles.grid1}>
            <div className={styles.inputGroup}>
              <label>Principal Name *</label>
              <input
                data-field="principalName"
                className={inputClass("principalName")}
                value={formData.principalName}
                onChange={(e) => updateField("principalName", e.target.value)}
                placeholder="Enter principal’s full name"
              />
              {showErrors && errors.principalName && <p className={styles.errorText}>{errors.principalName}</p>}
            </div>

            <div className={styles.grid2}>
              <div className={styles.inputGroup}>
                <label>Mobile Number *</label>
                <input
                  data-field="principalMobile"
                  className={inputClass("principalMobile")}
                  value={formData.principalMobile}
                  onChange={(e) => updateField("principalMobile", e.target.value)}
                  placeholder="10-digit mobile number"
                />
                {showErrors && errors.principalMobile && <p className={styles.errorText}>{errors.principalMobile}</p>}
              </div>

              <div className={styles.inputGroup}>
                <label>Email *</label>
                <input
                  data-field="principalEmail"
                  className={inputClass("principalEmail")}
                  value={formData.principalEmail}
                  onChange={(e) => updateField("principalEmail", e.target.value)}
                  placeholder="principal@example.com"
                />
                {showErrors && errors.principalEmail && <p className={styles.errorText}>{errors.principalEmail}</p>}
              </div>
            </div>

            <div className={styles.inputGroup}>
              <label>Alternate Phone</label>
              <input
                data-field="principalAltPhone"
                className={styles.inputElement}
                value={formData.principalAltPhone}
                onChange={(e) => updateField("principalAltPhone", e.target.value)}
                placeholder="10-digit mobile number (optional)"
              />
            </div>
          </div>
        </section>

        {/* Registrar */}
        <section className={styles.card}>
          <h3 className={styles.cardTitle}>Registrar Contact Information</h3>
          <div className={styles.grid1}>
            <div className={styles.inputGroup}>
              <label>Registrar Name *</label>
              <input
                data-field="registrarName"
                className={inputClass("registrarName")}
                value={formData.registrarName}
                onChange={(e) => updateField("registrarName", e.target.value)}
                placeholder="Enter registrar’s full name"
              />
              {showErrors && errors.registrarName && <p className={styles.errorText}>{errors.registrarName}</p>}
            </div>

            <div className={styles.grid2}>
              <div className={styles.inputGroup}>
                <label>Email *</label>
                <input
                  data-field="registrarEmail"
                  className={inputClass("registrarEmail")}
                  value={formData.registrarEmail}
                  onChange={(e) => updateField("registrarEmail", e.target.value)}
                  placeholder="registrar@example.com"
                />
                {showErrors && errors.registrarEmail && <p className={styles.errorText}>{errors.registrarEmail}</p>}
              </div>

              <div className={styles.inputGroup}>
                <label>Mobile Number *</label>
                <input
                  data-field="registrarMobile"
                  className={inputClass("registrarMobile")}
                  value={formData.registrarMobile}
                  onChange={(e) => updateField("registrarMobile", e.target.value)}
                  placeholder="10-digit mobile number"
                />
                {showErrors && errors.registrarMobile && <p className={styles.errorText}>{errors.registrarMobile}</p>}
              </div>
            </div>

            <div className={styles.inputGroup}>
              <label>Alternate Phone</label>
              <input
                data-field="registrarAltPhone"
                className={styles.inputElement}
                value={formData.registrarAltPhone}
                onChange={(e) => updateField("registrarAltPhone", e.target.value)}
                placeholder="10-digit mobile number (optional)"
              />
            </div>
          </div>
        </section>

        {/* Buttons */}
        <div className={styles.buttonRow}>
          <button className={styles.secondaryBtn} onClick={saveDraft}>Save Draft</button>
          <button className={styles.primaryBtn} onClick={handleNextStep}>Next Step</button>
        </div>
      </div>
    </DashboardLayout>
  );
}
