import { useState, useEffect } from "react";
import styles from "./Login.module.css";
import Language from "../../assets/language.svg";
import { useNavigate } from "react-router-dom";
import { demoUsers } from "../../data/demoUsers";

export default function Login() {
  const [language, setLanguage] = useState<"English" | "मराठी">("English");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const [step, setStep] = useState<"login" | "otp">("login");

  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [generatedOtp, setGeneratedOtp] = useState("");

  const [timer, setTimer] = useState(30);
  const [canResend, setCanResend] = useState(false);

  const [errors, setErrors] = useState<{
    username?: string;
    password?: string;
  }>({});

  const navigate = useNavigate();

  // -----------------------------
  // Load language
  // -----------------------------
  useEffect(() => {
    const saved = localStorage.getItem("lang");
    if (saved === "English" || saved === "मराठी") setLanguage(saved);
  }, []);

  useEffect(() => {
    localStorage.setItem("lang", language);
  }, [language]);

  // -----------------------------
  // OTP TIMER
  // -----------------------------
  useEffect(() => {
    if (step === "otp" && timer > 0) {
      const t = setInterval(() => setTimer((prev) => prev - 1), 1000);
      return () => clearInterval(t);
    }
    if (timer === 0) setCanResend(true);
  }, [step, timer]);

  // -----------------------------
  // LANGUAGE SWITCH
  // -----------------------------
  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "English" ? "मराठी" : "English"));
  };

  // -----------------------------
  // LOGIN SUBMIT
  // -----------------------------
  const handleSubmit = () => {
    const newErrors: { username?: string; password?: string } = {};

    if (!username.trim()) newErrors.username = "Username is required";
    if (!password.trim()) newErrors.password = "Password is required";

    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    // Lookup user
    const user = demoUsers.find(
      (u) => u.username === username && u.password === password
    );

    if (!user) {
      alert("Invalid username or password!");
      return;
    }

    // Store logged-in user
    localStorage.setItem(
      "user",
      JSON.stringify({
        username: user.username,
        name: user.name,
        email: user.email,
        role: user.role,
      })
    );
    localStorage.setItem("role", user.role);

    // ---------- OTP GENERATION ----------
    const newOTP = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newOTP);
    console.log("OTP SENT →", newOTP); // (REMOVE IN PRODUCTION)

    // reset fields
    setOtp(["", "", "", "", "", ""]);
    setTimer(30);
    setCanResend(false);

    setStep("otp");
  };

  // -----------------------------
  // OTP INPUT LOGIC
  // -----------------------------
  const handleOtpChange = (value: string, index: number) => {
    if (!/^\d?$/.test(value)) return;

    const copy = [...otp];
    copy[index] = value;
    setOtp(copy);

    // Auto focus next input
    if (value && index < 5) {
      const next = document.getElementById(`otp-${index + 1}`);
      next?.focus();
    }

    const fullOtp = copy.join("");

    // Trigger AFTER all digits entered
    if (copy.every((d) => d !== "")) {
      if (fullOtp === generatedOtp) {
        alert("OTP Verified Successfully!");
        navigate("/dashboard");
      } else {
        alert("Incorrect OTP! Please try again.");
        setOtp(["", "", "", "", "", ""]);
        const first = document.getElementById("otp-0");
        first?.focus();
      }
    }
  };

  const handleBackspace = (
    e: React.KeyboardEvent<HTMLInputElement>,
    index: number
  ) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      const prev = document.getElementById(`otp-${index - 1}`);
      prev?.focus();
    }
  };

  // -----------------------------
  // RESEND OTP
  // -----------------------------
  const handleResend = () => {
    const newOTP = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(newOTP);
    console.log("OTP RESENT →", newOTP);

    setOtp(["", "", "", "", "", ""]);
    setTimer(30);
    setCanResend(false);
  };

  // ------------------------------------------------------------
  // RENDER UI
  // ------------------------------------------------------------
  return (
    <div className={styles.login_page}>
      <button className={styles.language_btn} onClick={toggleLanguage}>
        <img src={Language} alt="icon" width={24} /> {language}
      </button>

      <div className={styles.container}>
        {/* HEADER */}
        <div className={styles.header}>
          <div className={styles.badge}>DHE</div>
          <h2 className={styles.title}>DHE MIS</h2>
          <p className={styles.subtitle}>
            {language === "English"
              ? "Department of Higher Education - Management Information System"
              : "उच्च शिक्षण विभाग - व्यवस्थापन माहिती प्रणाली"}
          </p>
        </div>

        {/* ------------ LOGIN UI ------------- */}
        {step === "login" && (
          <div className={styles.login_container}>
            <h3>Login to DHE MIS</h3>

            <label>Username *</label>
            <input
              type="text"
              placeholder="Enter your username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
            {errors.username && (
              <p className={styles.error}>{errors.username}</p>
            )}

            <label>Password *</label>
            <input
              type="password"
              placeholder="Enter your password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            {errors.password && (
              <p className={styles.error}>{errors.password}</p>
            )}

            <button onClick={handleSubmit} className="login-btn">
              Send OTP
            </button>

            <p className="demo">
              Demo: admin/admin, institute/institute, jd/jd, director/director,
              secretary/secretary
            </p>
          </div>
        )}

        {/* ------------ OTP SCREEN ------------- */}
        {step === "otp" && (
          <div className={styles.login_container}>
            <h3>Verify OTP</h3>
            <p className={styles.small_text}>
              Enter the OTP sent to your registered number
            </p>

            <p className={styles.logged_in_as}>Logged-in as: {username}</p>

            <div className={styles.otp_boxes}>
              {otp.map((val, idx) => (
                <input
                  key={idx}
                  id={`otp-${idx}`}
                  maxLength={1}
                  value={val}
                  onChange={(e) => handleOtpChange(e.target.value, idx)}
                  onKeyDown={(e) => handleBackspace(e, idx)}
                />
              ))}
            </div>

            {!canResend ? (
              <p className={styles.resend}>
                Resend OTP in <span>({timer}s)</span>
              </p>
            ) : (
              <p className={styles.resend_link} onClick={handleResend}>
                Resend OTP
              </p>
            )}

            <button
              className={styles.back_btn}
              onClick={() => setStep("login")}
            >
              ← Back to Login
            </button>
          </div>
        )}

        {/* FOOTER */}
        <p className={styles.footer}>
          © 2024 Department of Higher Education, Maharashtra. All rights
          reserved.
        </p>
      </div>
    </div>
  );
}
