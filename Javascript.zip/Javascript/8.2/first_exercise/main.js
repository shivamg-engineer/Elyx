import { capitalize,reverseString } from "./stringUtils.js";


const name = "shivam";
const company = "elyx";


console.log(capitalize(name));       // Output: Shivam
console.log(reverseString(company)); 