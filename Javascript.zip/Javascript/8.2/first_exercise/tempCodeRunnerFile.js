import { capitalize,reverseString } from "./stringUtils";

const name="shivam";
const company="elyx";
console.log(capitalize(name));
console.log(reverseString(company));