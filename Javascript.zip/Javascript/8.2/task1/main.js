import {add, sub} from "./mathUtils.js";

console.log(add(3,4));
console.log(sub(6,3));