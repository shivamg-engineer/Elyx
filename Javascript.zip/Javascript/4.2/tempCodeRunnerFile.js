

console.log(Object.getPrototypeOf(Product)); // [Function]
console.log(Product.prototype); // methods live here