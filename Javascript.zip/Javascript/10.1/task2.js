function greetUser(name) {
  let message = "Hello, " + name;
  console.log(message);
  return message;
}
greetUser("Alice");
