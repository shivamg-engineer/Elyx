// Exercise 2: Fixing Syntax Errors

// Identify and correct the syntax error in this code snippet.


let user = "John";
console.log(user);