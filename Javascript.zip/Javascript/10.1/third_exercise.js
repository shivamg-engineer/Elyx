// Exercise 3: Using DevTools to Track Errors

// Open DevTools, run the following script, and find the error.


let numbers = [1, 2, 3,4,5,6];
console.log(numbers[5].toString());