// Exercise 4: Debugging an Infinite Loop

// Find and fix the issue causing an infinite loop in this snippet.


let count = 0;
while (count < 5) {
  console.log(count);
  count++;
}


