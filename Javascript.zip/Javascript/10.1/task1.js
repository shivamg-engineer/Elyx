// 1. Using console.log() for Debugging

// Task: Identify issues in the following JavaScript function using console.log().



function calculateSum(a, b) {
const result = a + b;  
  console.log("Inside function, result =", result);
  return result;
}
console.log(calculateSum(5, 10));
