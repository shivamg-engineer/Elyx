// Exercise 1: Debugging Undefined Variables

// Fix the issue in the following code where the variable is not defined.

let message="hello there"

function printMessage() {
  console.log(message);
}
printMessage();
