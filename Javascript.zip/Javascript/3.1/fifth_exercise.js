function findLargest(...arg){
return Math.max(...arg);
}

console.log(findLargest(3,5,33,23));