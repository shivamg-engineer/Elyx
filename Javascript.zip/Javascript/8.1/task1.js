const numbers=[55,43,65,3];
const [ first, second,third]=numbers;
console.log(first,second,third);

const user={name:"shreya",age:43};
const {name,age}=user;

console.log(name,age);