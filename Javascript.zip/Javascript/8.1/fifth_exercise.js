let name = "Alice";
let age = 28;
console.log("Hello, my name is " + name + " and I am " + age + " years old.");
