const Book={ title: "Book", author: "Author", year: 2023 };
const {title,author}=Book;
console.log(title,author);