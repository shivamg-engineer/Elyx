const firstName="john";
const age=55;
console.log(`the age of ${firstName} is ${age}`);