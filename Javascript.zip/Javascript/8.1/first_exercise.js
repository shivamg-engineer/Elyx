const arr=[10, 20, 30, 40]
const[first,second]=arr;
console.log(first,second);

