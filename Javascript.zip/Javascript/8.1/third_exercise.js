const fruitList1=["apple", "banana"];
const fruitList2=["cherry", "mango"];
const mergedFruitList=[...fruitList1,...fruitList2];
console.log(mergedFruitList);