const _ = require("lodash");
console.log(_.capitalize("hello world"));

// function solve(){

// }
// solve=()=>{

// }
// const name= function(){

// }

solve();

function solve(){
    console.log('hello');
}

// const solve= function(){
//     console.log('demo');
// }