// Exercise 3: Sorting Names Alphabetically

// Create an array of names.
// Sort them in ascending order using sort().
// Print the sorted list.

const arr=[43,65,21,1];
arr.sort();
console.log(arr);