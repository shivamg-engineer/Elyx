
players.shift();