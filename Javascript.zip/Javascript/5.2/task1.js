// 1. Adding, Removing, and Updating Arrays

// Task: Use array methods to manipulate elements dynamically.

let players = ["Alice", "Bob", "Charlie"];

players.push("David");
players.unshift("Eve");

players.pop();
players.shift();

players[1]="Zara";

console.log(players);