const user={firstName:"John" , lastName:"Doe", age: 30};

const name=user.firstName;
const age= user.age;

console.log(`The age of ${name} is ${age}`);

// Challenge:
// Modify the following code to use object destructuring:
const car = { brand: "Toyota", model: "Corolla", year: 2020 };
const brand = car.brand;
const model = car.model;
console.log(brand, model);
