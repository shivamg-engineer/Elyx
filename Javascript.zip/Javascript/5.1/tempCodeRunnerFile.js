.entries(person).forEach(([key, value]) => {
//   console.log(`${key}: ${value}`);
// });