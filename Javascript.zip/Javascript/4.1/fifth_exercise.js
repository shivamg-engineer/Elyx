// 5. Use Static Methods for Utility Functions


// Task:


// Create a MathHelper class with a static method square() that returns the square of a number.

class MathHelper{

    static square(num){
        return num*num;
    }
}

console.log(MathHelper.square(4)); // 16