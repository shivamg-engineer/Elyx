// 4. Sum All Numbers Using reduce()
const numbers = [5, 10, 15, 20];
const sum=numbers.reduce((total,num)=>total+num,0);
console.log(sum);