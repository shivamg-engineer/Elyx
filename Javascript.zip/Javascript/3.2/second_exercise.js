const names = ["alice", "bob", "charlie"];

const upperNames= names.map((name)=>name.toUpperCase());
console.log(upperNames);