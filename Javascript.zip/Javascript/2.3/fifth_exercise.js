let i = 1;
while (true) {
    if (i % 3 == 0 && i % 5 == 0) {
        console.log(i);
        break;
    }
    i++;
}
