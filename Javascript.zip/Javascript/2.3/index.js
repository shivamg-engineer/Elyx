const number=[1,2,3,4];
number.forEach(num=> console.log(num*2));